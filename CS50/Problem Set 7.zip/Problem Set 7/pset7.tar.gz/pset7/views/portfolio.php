<?php if(!empty($_GET["message"])){?>
<p><?= $_GET["message"] ?></p>
<?php } ?>
<table class="table table-bordered ">
	<thead>
	    <tr class="info">>
    		<th>Symbol</th>
    		<th>Name</th>
    		<th>Shares</th>
    		<th>Price</th>
    		<th>TOTAL</th>
    	</tr>
	</thead>
	<tbody>
	    <?php 
	    
	    $value = 0;
	    foreach ($positions as $position): 
            $value =$position["price"]*$position["shares"];
            $cash = $cash - $value;
            ?>
            <tr>
                <td class="text-left"><?= $position["symbol"] ?></td>
                <td class="text-left"><?= $position["name"] ?></td>
                <td class="text-left"><?= $position["shares"] ?></td>
                <td class="text-left"><?= $position["price"] ?></td>
                <td class="text-left"><?= number_format($value,2) ?></td>
                
            </tr>

       <?php endforeach ?>  
       
       <tr class="info">>
           <td class="text-left" colspan="4"><strong>CASH</strong></td>
           <td class="text-left"><strong><?=number_format($cash,2)?></strong></td>
       </tr>   
       
	</tbody>
	
</table>

<div>
     <a onclick = "goBack()">Go Back</a>
</div>
