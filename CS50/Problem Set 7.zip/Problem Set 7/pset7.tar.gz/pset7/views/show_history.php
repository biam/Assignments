<table class="table table-bordered ">
	<thead>
	    <tr class="info">>
    		<th>Type</th>
    		<th>Symbol</th>
    		<th>Shares</th>
    		<th>Price</th>
    		<th>Time</th>
    	</tr>
	</thead>
	<tbody>
	    <?php foreach ($values as $value): ?>
            <tr>
                <td class="text-left"><?= $value["type"] ?></td>
                <td class="text-left"><?= $value["symbol"] ?></td>
                <td class="text-left"><?= $value["shares"] ?></td>
                <td class="text-left"><?= number_format($value["price"],2) ?></td>
                <td class="text-left"><?= $value["time"] ?></td>
                
            </tr>

       <?php endforeach ?>  
       
	</tbody>
	
</table>

<div>
     <a onclick = "goBack()">Go Back</a>
</div>
