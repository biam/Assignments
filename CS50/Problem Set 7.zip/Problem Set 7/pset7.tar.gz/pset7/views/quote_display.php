<p>

    <?= htmlspecialchars( $stock["name"]) ?> costs <b>$<?=  $stock["price"] ?> </b>
<p>
<div>
     <a onclick = "goBack()">Go Back</a>
</div>
