<?php

    // configuration
    require("../includes/config.php");
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        $rows = CS50::query("SELECT * FROM history WHERE user_id = ?", $_SESSION["id"]);
        $values = [];
        foreach ($rows as $row)
        {
               $values[] = [
                    "type" => $row["type"],
                    "price" => $row["price"],
                    "shares" => $row["shares"],
                    "symbol" => $row["symbol"],
                    "time" => $row["time"]
                ];
        } 
        render("show_history.php", ["values" => $values,"title" => "History"]);
    }
    
    

?>