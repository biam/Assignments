<?php

    // configuration
    require("../includes/config.php"); 
    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // render buy_form
        render("buy_form.php", ["title" => "Buy"]);
    }

    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST"){
        if(empty($_POST["symbol"])){
            apologize("Please input the symbol");
        }
        else if(empty($_POST["shares"])){
            apologize("No shares mentioned.");
        }else if (preg_match("/^\d+$/", $_POST["shares"]) == false){
            apologize("Invalid number of shares.");
        }else{
            $stock = lookup($_POST["symbol"]);
            $cash = CS50::query("SELECT cash from users where id=?", $_SESSION["id"]);
            if($cash[0]["cash"] < $stock["price"] ){
                apologize("Not enough amount to buy.");
            }
            CS50::query("INSERT INTO portfolios(user_id,symbol,shares,price) values(?,?,?,?)", $_SESSION["id"],strtoupper($stock["symbol"]),$stock["price"],$_POST["shares"]);
            CS50::query("UPDATE users SET cash=cash-? WHERE id = ?", $stock["price"]*$shares["shares"], $_SESSION["id"]);
            CS50::query("INSERT into history(user_id,type,symbol,shares,price,time) values (?,'BUY',?,?,?,CURRENT_TIMESTAMP)",$_SESSION["id"],strtoupper($stock["symbol"]),$shares["shares"],$stock["price"]);
        }
        redirect("/");
    }

    
   
    
?>
