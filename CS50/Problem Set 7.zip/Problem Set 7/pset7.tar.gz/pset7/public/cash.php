<?php

    // configuration
    require("../includes/config.php"); 
    
    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("cash_form.php", ["title" => "Add cash"]);
    }

    // if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        // validate submission
        if (empty($_POST["amount"]))
        {
            apologize("Please provide a valid amount.");
        }else if ($_POST["amount"] <= 0)
        {
            apologize("Please provide a valid amount.");
        }else if (empty($_POST["password"]))
        {
            apologize("You must provide your password.");
        }

        // query database for user
        $rows = CS50::query("SELECT * FROM users WHERE id = ?", $_SESSION["id"]);

        // if we found user, check password
        if (count($rows) == 1)
        {
            // first (and only) row
            $row = $rows[0];

            // compare hash of user's input against hash that's in database
            if (password_verify($_POST["password"], $row["hash"]))
            {
                CS50::query("UPDATE users SET cash=cash+? WHERE id = ?",$_POST["amount"],$_SESSION["id"]);
                $message = "Congratulations, you just added $".$_POST["amount"]." to your account!";
                //echo "<script type='text/javascript'>alert('Congratulations you just added cash to your account')</script>";
                // redirect to portfolio
                 redirect("/?message=$message");
            }else{
                apologize("Invalid password.");        
            }
        }

        
        
    }

?>
