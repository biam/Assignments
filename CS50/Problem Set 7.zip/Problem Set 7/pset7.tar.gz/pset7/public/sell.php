<?php

    // configuration
    require("../includes/config.php"); 
    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
         $rows = CS50::query("SELECT symbol FROM portfolios WHERE user_id = ?", $_SESSION["id"]);
        // render sell_form
        render("sell_form.php", ["rows" => $rows, "title" => "Sell"]);
    }

    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST"){
        if(empty($_POST["symbol"])){
            apologize("No stock selected");
        }
        else{
            $stock = lookup($_POST["symbol"]);
            $shares = CS50::query("SELECT shares FROM portfolios WHERE user_id = ? AND symbol=?", $_SESSION["id"],$stock["symbol"]);
            $shares = $shares[0];
            if($shares["shares"] == 0){
                apologize("Nothing to sell");
            }else{
                CS50::query("UPDATE users SET cash=cash+? WHERE id = ?", $stock["price"]*$shares["shares"], $_SESSION["id"]);
                CS50::query("INSERT into history(user_id,type,symbol,shares,price,time) values (?,'SELL',?,?,?,CURRENT_TIMESTAMP)",$_SESSION["id"],strtoupper($stock["symbol"]),$shares["shares"],$stock["price"]);
                CS50::query("DELETE FROM portfolios WHERE user_id = ? AND symbol = ?",$_SESSION["id"],strtoupper($stock["symbol"]));    
            }
            redirect("/");
            
        }
    }

    
   
    
?>
