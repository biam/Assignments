<?php

    // configuration
    require("../includes/config.php");
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("quote_form.php", ["title" => "Quote"]);
    }
    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        if(empty($_POST["symbol"])){
            apologize("No symbol sent.");
        }else{
            $symbol =  $_POST["symbol"];   
            $stock = lookup($_POST["symbol"]);    
            if ($stock == false)
            {
                apologize("Symbol not found.");
            }
            else
            {
                render("quote_display.php", ["stock" => $stock,"title" => "Quote"]);
            }
        
        }
    }

?>